touch config/stop_flag.txt
